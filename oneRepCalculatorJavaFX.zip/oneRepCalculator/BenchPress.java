import java.util.Scanner;

public class BenchPress {

    public static double calculateOneRepMax(double weightLifted, int numReps) {
        double oneRepMax = weightLifted * (1 + numReps/36.0); // Epley formula
        return oneRepMax;
    }
    public static double calculateBenchPressPercentile(double oneRepMax) {
        double mean = 185; // mean one rep max for adult male bench pressers
        double sd = 50; // standard deviation of one rep max for adult male bench pressers
        double zScore = (mean - oneRepMax) / sd; // reverse the order to get the number of lifters who are weaker than you
        double percentile = 0.5 * (1 + erf(zScore / Math.sqrt(2)));
        return percentile;
    }
    public static int factorial(int n) {
        int result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
    public static double erf(double x) {
        // implementation of the error function using the Maclaurin series, used to calculate standard normal distribution
        double result = 0;
        for (int n = 0; n < 10; n++) {
            result += Math.pow(-1, n) * Math.pow(x, 2*n+1) / (factorial(n) * (2*n+1));
        }
        return 2 / Math.sqrt(Math.PI) * result;

}
}