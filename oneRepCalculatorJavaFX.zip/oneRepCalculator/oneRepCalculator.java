import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class oneRepCalculator extends Application {

    private ComboBox<String> liftSelection;
    private TextField weightLifted;
    private TextField numReps;
    private Label resultLabel;
    	//create window for text, dropdown menu, entry boxes
    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        // add lift selection dropdown
        Label liftLabel = new Label("Select a lift:");
        liftSelection = new ComboBox<>();
        liftSelection.getItems().addAll("Squat", "Deadlift", "Bench Press");
        liftSelection.getSelectionModel().selectFirst();
        gridPane.add(liftLabel, 0, 0);
        gridPane.add(liftSelection, 1, 0);

        // add weight lifted field
        Label weightLabel = new Label("Weight lifted:");
        weightLifted = new TextField();
        gridPane.add(weightLabel, 0, 1);
        gridPane.add(weightLifted, 1, 1);

        // add number of reps field
        Label repsLabel = new Label("Number of reps:");
        numReps = new TextField();
        gridPane.add(repsLabel, 0, 2);
        gridPane.add(numReps, 1, 2);

        // add calculate button
        Button calculateButton = new Button("Calculate");
        calculateButton.setOnAction(event -> calculateOneRepMax());
        gridPane.add(calculateButton, 1, 3);

        // add result label
        resultLabel = new Label();
        gridPane.add(resultLabel, 1, 4);

        // create scene and show window
        Scene scene = new Scene(gridPane, 400, 250);
        primaryStage.setTitle("One Rep Max Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void calculateOneRepMax() {
        try {
            double weight = Double.parseDouble(weightLifted.getText());
            int reps = Integer.parseInt(numReps.getText());
            int liftIndex = liftSelection.getSelectionModel().getSelectedIndex();

            double oneRepMax = 0;
            switch (liftIndex) {
            case 0: //case for squat
                oneRepMax = Squat.calculateOneRepMax(weight, reps);
                weight = Squat.calculateSquatPercentile(oneRepMax);
                break;
            case 1: //case for deadlift
                oneRepMax = Deadlift.calculateOneRepMax(weight, reps);
                weight = Deadlift.calculateDeadliftPercentile(oneRepMax);
                break;
            case 2: //case for benchpress
                oneRepMax = BenchPress.calculateOneRepMax(weight, reps);
                weight = BenchPress.calculateBenchPressPercentile(oneRepMax);
                break;
            default: //if invalid lift is selected, display error message, this should no longer be possible now that lift is selected with dropdown menu
                resultLabel.setText("Invalid lift selection");
                return;
        }
            	//display results
        resultLabel.setText(String.format("Your one rep max is %.2f.\nYou are in the top %.2f%% of lifters.", oneRepMax, weight));
        		//error message if integer / decimal is not entered for weight
        } catch (NumberFormatException e) {
            resultLabel.setText("Invalid input");
        }
    }
   
  
    //method to calculate factorial of a number
    public static int factorial(int n) {
        int result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
    public static double erf(double x) {
        // implementation of the error function using the Maclaurin series, used to calculate standard normal distribution
        double result = 0;
        for (int n = 0; n < 10; n++) {
            result += Math.pow(-1, n) * Math.pow(x, 2*n+1) / (factorial(n) * (2*n+1));
        }
        return 2 / Math.sqrt(Math.PI) * result;
}
}
